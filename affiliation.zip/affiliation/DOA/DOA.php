<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DOA
 *
 * @author hilaire
 */
class DOA {

    //put your code here
    private $endPointParams;
    private $model;
    private $data;

    public function setUrlData($data) {
        $this->data = $data;
    }

    public function getUrlData() {
        return $this->data;
    }

    //This function has to be called in each DAO to receive the class model it is accessing
    public function setModel($model) {
        $this->model = $model;
    }

    public function getEndPointParameters() {
        $this->endPointParams = array(
            "lhsIP" => "197.243.0.244",
            "ghrPort" => 8880,
            "lhsIP" => "175.139.242.87", // LHS IP address 
            "lhsPort" => 8880           // LHS HTTP port 
        );
        return $this->endPointParams;
    }

    public function genRand() {
        $rand = substr(md5(microtime()), rand(0, 26), 10);
        return $rand;
    }

    public function createHandleRecord() {
        $method = 'POST';
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: LBE7YRZPUCOCLQOXBMPJUWKS0EMUZ8MJ';
        $random = $this->genRand();
        $url = 'https://197.243.0.244:8880/25.001/DMMHEHE/' . $this->model . '/' . $random;
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_URL => $url,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => ($this->data)
        ));
        $output = curl_exec($curl);
        echo $output;
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return "cURL Error #:" . $err . $output;
        } else {
            //$resCode = json_decode($output);
            return $output;
        }
    }

}
