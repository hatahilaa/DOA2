<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AgentDao
 *
 * @author hilaire
 */
require_once '../models/Agent.php';
require_once '../util/DBUtil.php';
require_once '../DOA/DOA.php';

class AgentDao {

    //put your code here
    private $queryExecution; //This variable is common for all Data Access Objects. It has to be declared once
    private $urlData;
    private $secureHashSecret;

    public function setSecret() {
        $this->secureHashSecret = "C5FD7C7B3284E4F8345D89A2573CE42B";
    }

    public function getSecret() {
        return $this->secureHashSecret;
    }

    public function agentSignUp() {
        $Agent = new Agent();
        $dbutil = new DBUtil();
        $DOA = new DOA();
        //Setting Agent Data from sign up form//
        $Agent->setAgentAccount($_POST['agentAccount']); //Account on which commision will be paid
        $Agent->setAgentEmail($_POST['agentEmail']);

        $Agent->setAgentPassword($_POST['agentPassword']);
        $Agent->setAgentUserName($_POST['agentUsername']);
        //Getting actual Product ID//
        ///Set Database parameters for connection///

        $dbutil->getHostParameters($dbutil->setParams());
        $conn = $dbutil->getConnection();
        $this->queryExecution = mysqli_query($conn, "SELECT MAX(`agentId`) as lastAgentId FROM `Agent`");
        $this->urlData = '{	
	"values": [{
		"type": "agentId",
		"value": "' . (1 + mysqli_fetch_object($this->queryExecution)->lastAgentId) . '",
		"adminRead": true,
		"adminWrite": true,
		"publicRead": true,
		"publicWrite": false,
		"index": "1001"
                
	          }, 
                  {
                    "type":"agentAccount",
                    "value":"' . ($Agent->getAgentAccount()) . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1002"
                
	          
                  }, 
                  {
                    "type":"agentEmail",
                    "value":"' . ($Agent->getAgentEmail()) . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1003"
                
	          
                  }, 
                  {
                    "type":"agentUsername",
                    "value":"' . $Agent->getAgentUserName() . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1004"
                
	          
                  }, 
                  {
                    "type":"agentPassword",
                    "value":"' . ($Agent->getAgentPassword()) . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1005"
                
	          
                  }]
               }';
        $DOA->setUrlData($this->urlData); //Data to to be in Handle Record
        $DOA->getUrlData();
        //seting Model name to be used in Handle ID
        $DOA->setModel(get_class($Agent));
        $DOAresponse = json_decode($DOA->createHandleRecord());
        //From end_point response//
        $Agent->setAgentHandleId($DOAresponse->handle); //After creating him/her a Handle Record
        ///Insert a record in our Database only if the Handle record is created
        if ($DOAresponse->responseCode == 1) {

            $query = "INSERT INTO `Agent` ( `agentAccount`, `agentEmail`, `agentUsername`, `agentPassword`, `agentHandleId`) VALUES ( '" . $Agent->getAgentAccount() . "', '" . $Agent->getAgentEmail() . "', '" . $Agent->getAgentUserName() . "', '" . $Agent->getAgentPassword() . "', '" . $Agent->getAgentHandleId() . "')";
            $this->queryExecution = mysqli_query($conn, $query) or die(mysqli_error($conn));
            return $this->queryExecution;
        }
    }

    public function agentSignIn($userName, $password) {
        $dbutil = new DBUtil();
        $dbutil->getHostParameters($dbutil->setParams());
        $conn = $dbutil->getConnection();
        $query = "SELECT * FROM `Agent` WHERE `agentUsername`='" . $userName . "' AND `agentPassword`='" . $password . "'";
        $this->queryExecution = mysqli_query($conn, $query);
        if (mysqli_num_rows($this->queryExecution) != 0) {
            //User exists//
            //Set secret key
            $this->setSecret();
            $logedAgentData = $userName . (mysqli_fetch_object($this->queryExecution)->agentEmail) . (mysqli_fetch_object($this->queryExecution)->agentHandleId);
            return hash_hmac('SHA256', $logedAgentData, $this->getSecret());
        } else {
            //User is not registered. Redirect Him/her to sign up//
        }
    }

}
