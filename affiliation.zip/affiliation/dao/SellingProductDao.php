<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SellingProductDao
 *
 * @author hilaire
 */
require_once '../models/SellingProduct.php';
require_once '../util/DBUtil.php';
require_once '../DOA/DOA.php';

class SellingProductDao {

    //put your code Util objects 
    private $queryExecution;

    public function selProduct() {
        $SellingProduct = new SellingProduct();
        $DBUtil = new DBUtil();
        $DOA = new DOA();
        //Database Connection 
        $DBUtil->getHostParameters($DBUtil->setParams());
        $link = $DBUtil->getConnection();
        //Setting Product Selling data
        $SellingProduct->setSelDate(date("Y-m-d"));
        $SellingProduct->setSelProductId(2343);
        $SellingProduct->setSelAgentId(121);
        $SellingProduct->setSelResponse("Response"); //From payment service provider

        $this->queryExecution = mysqli_query($link, "SELECT MAX(`selId`) as LastSelId FROM `sellingProduct` ");
        $this->urlData = '{	
	"values": [{
		"type": "selId",
		"value": "' . (1 + mysqli_fetch_object($this->queryExecution)->LastSelId) . '",
		"adminRead": true,
		"adminWrite": true,
		"publicRead": true,
		"publicWrite": false,
		"index": "1001"
	          }, 
                  {
                    "type":"selDate",
                    "value":"' . ($SellingProduct->getSelDate()) . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1002"
                  }, 
                  {
                    "type":"selProcuctId",
                    "value":"' . ($SellingProduct->getSelProductId()) . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1003"
                  }, 
                  {
                    "type":"paymentResponse",
                    "value":"' . $SellingProduct->getSelAgentId() . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1004"
                  }, 
                  {
                    "type":"paymentResponse",
                    "value":"' . ($SellingProduct->getSelResponse()) . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1005" 
                  }]
               }';
        $DOA->setUrlData($this->urlData); //Data to to be in Handle Record
        $DOA->getUrlData();
        //seting Model name to be used in Handle ID
        $DOA->setModel(get_class($SellingProduct));
        $DOAresponse = json_decode($DOA->createHandleRecord());
        //From end_point response//
        $SellingProduct->setSelHandleId($DOAresponse->handle); //After creating a Handle Record
        ///Insert a record in our Database only if the Handle record is created
        if ($DOAresponse->responseCode == 1) {
            $query = "INSERT INTO `sellingProduct` ( `TransactionHandleId`, `selProduct`, `selAgent`, `selDate`, `selResponse`) VALUES ( '" . $SellingProduct->getSelHandleId() . "', '" . $SellingProduct->getSelProductId() . "', '" . $SellingProduct->getSelAgentId() . "', '" . $SellingProduct->getSelDate() . "', '" . $SellingProduct->getSelResponse() . "')";
            $this->queryExecution = mysqli_query($link, $query) or die(mysqli_error($link));
            return $this->queryExecution;
        }
    }

}
