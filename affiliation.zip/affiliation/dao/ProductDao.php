<?php

/* * *****************************************************************************
 * To change this license header, choose License Headers in Project Properties.*
 * To change this template file, choose Tools | Templates                      *
 * and open the template in the editor.                                        *
 * ***************************************************************************** */

/* * **************************
 * Description of ProductDao*
 *                          *
 * @author hilaire          *
 * ************************** */
require_once '../models/Product.php';
require_once '../util/DBUtil.php';
require_once '../DOA/DOA.php';

class ProductDao {

    private $hostParams; //DB parameters
    private $queryExecution;
    private $urlData;

    //put your code here
    public function setParams() {
        $this->hostParams = array(
            0 => "localhost",
            1 => "root",
            2 => "Hatahila@2017",
            3 => "affiliation"
        );
        return $this->hostParams;
    }

    public function addProduct() {
        /* Establish connection */
        $product = new Product();
        $dbutil = new DBUtil();
        $DOA = new DOA();
        ////get_class($this)
        $dbutil->getHostParameters($this->setParams());

        //print_r($dbutil->getConnection());

        /* Set product data from the form */
        $product->setProductName($_POST['productName']);
        $product->setProductPrice($_POST['productPrice']);
        $product->setProductImage($_POST['productImage']);
        $product->setProductPrice($_POST['productPrice']);
        $product->setProductPercentage($_POST['productPercentage']);

        $product->setProductUrl('https://'.$_SERVER['HTTP_HOST'].'/product/'.strtolower($_POST['productName']));
        //Getting actual Product ID//
        $this->queryExecution = mysqli_query($dbutil->getConnection(), "SELECT MAX(`productId`) as `lastProductId` FROM `Product`");
        $this->urlData = '{	
	"values": [{
		"type": "productId",
		"value": "'.(1+ mysqli_fetch_object($this->queryExecution)->lastProductId).'",
		"adminRead": true,
		"adminWrite": true,
		"publicRead": true,
		"publicWrite": false,
		"index": "1001"
                
	          }, 
                  {
                    "type":"productName",
                    "value":"' . ($product->getProductName()) . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1002"
                
	          
                  }, 
                  {
                    "type":"productPrice",
                    "value":"' . ($product->getProductPrice()) . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1003"
                
	          
                  }, 
                  {
                    "type":"percentage",
                    "value":"' . $product->getProductPercentage() . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1004"
                
	          
                  }, 
                  {
                    "type":"productImage",
                    "value":"' . ($product->getProductImage()) . '",
                    "adminRead": true,
                    "adminWrite": true,
                    "publicRead": true,
		    "publicWrite": false,
		    "index": "1005"
                
	          
                  }]
               }';
        $DOA->setUrlData($this->urlData); //Data to to be in Handle Record
        $DOA->getUrlData();
        //seting Model name to be used in Handle ID
        $DOA->setModel(get_class($product));
        $DOAresponse = json_decode($DOA->createHandleRecord());
        //From end_point response//
        $product->setProductHandleId($DOAresponse->handle);
        ///Insert a record in our Database only if the Handle record is created
        if ($DOAresponse->responseCode == 1)
            $this->queryExecution = mysqli_query($dbutil->getConnection(), "INSERT INTO `Product` ( `productName`, `productHandleId`, `productPrice`, `percentage`, `productImage`,`DOAUrldata`,`productUrl`) VALUES ( '" . $product->getProductName() . "', '" . $product->getProductHandleId() . "'," . $product->getProductPrice() . ", " . $product->getProductPercentage() . ", '" . $product->getProductImage() . "','" . addslashes($product->getDOAUrldata()) . "','" . addslashes($product->getProductUrl()) . "')")or die("Query error");
        return $this->queryExecution;
    }

    public function getAllProducts() {
        $dbutil = new DBUtil();
        $dbutil->getHostParameters($this->setParams());
        $this->queryExecution = mysqli_query($dbutil->getConnection(), "SELECT * FROM Product");
        $data = array();
        $rows = 0;
        while ($row = mysqli_fetch_array($this->queryExecution)) {
            $data[$rows][] = $rows++;
        }
        return $row; //This must be a 2D array holding a list of all products
    }

    public function getSpecificProduct() {
        $dbutil = new DBUtil();
        $dbutil->getHostParameters($this->setParams());
        $this->queryExecution = mysqli_query($dbutil->getConnection(), "SELECT * FROM Product where productId = '" . $_POST['id'] . "'");

        while ($row = mysqli_fetch_assoc($this->queryExecution)) {
            
        }
        return $row; //This must be a 2D holding a list of all products
    }

}
