<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Agent
 *
 * @author hilaire
 */
class Agent {
    //put your code here
    private $agentAccount;
    private $agentId;
    private $agentEmail;
    private $agentUserName;
    private $agentPassword;
    private $agentHandleId;
    function getAgentId() {
        return $this->agentId;
    }
    function getAgentAccount() {
        return $this->agentAccount;
    }

    function getAgentEmail() {
        return $this->agentEmail;
    }

    function getAgentUserName() {
        return $this->agentUserName;
    }

    function getAgentPassword() {
        return $this->agentPassword;
    }

    function getAgentHandleId() {
        return $this->agentHandleId;
    }
    
    function setAgentAccount($agentAccount) {
        $this->agentAccount = $agentAccount;
    }

    function setAgentId($agentId) {
        $this->agentId = $agentId;
    }

    function setAgentEmail($agentEmail) {
        $this->agentEmail = $agentEmail;
    }

    function setAgentUserName($agentUserName) {
        $this->agentUserName = $agentUserName;
    }

    function setAgentPassword($agentPassword) {
        $this->agentPassword = $agentPassword;
    }

    function setAgentHandleId($agentHandleId) {
        $this->agentHandleId = $agentHandleId;
    }


}
