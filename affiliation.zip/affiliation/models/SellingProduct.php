<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SellingProduct
 *
 * @author hilaire
 */
class SellingProduct {
    //put your code here
   // $baseProduct = new Product();
   // $baseAgent = new Agent();
    private $selId;
    private $selDate;
    private $selProductId;
    private $selAgentId;
    private $selResponse;
    private $transactionHandleId;
    function getSelId() {
        return $this->selId;
    }

    function getSelDate() {
        return $this->selDate;
    }

    function getSelProductId() {
        return $this->selProductId;
    }

    function getSelAgentId() {
        return $this->selAgentId;
    }
    function getSelResponse() {
        return $this->selResponse;
    }
    function getSelHandleId() {
        return $this->transactionHandleId;
    }

    function setSelId($selId) {
        $this->selId = $selId;
    }

    function setSelDate($selDate) {
        $this->selDate = $selDate;
    }

    function setSelProductId($selProductId) {
        $this->selProductId = $selProductId;
    }

    function setSelAgentId($selAgentId) {
        $this->selAgentId = $selAgentId;
    }
    function setSelResponse($selResponse) {
        $this->selResponse =$selResponse;
    }
    function setSelHandleId($transactionHandleId) {
        $this->transactionHandleId = $transactionHandleId;
    }


}
