<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Product
 *
 * @author hilaire
 */
class Product {

    //put your code here
    private $productId;
    private $productName;
    private $productPrice;
    private $productHandleId;
    private $productImage;
    private $productPercentage;
    private $DOAUrldata;
    private $productUrl;

    public function getDOAUrldata() {
        return $this->DOAUrldata;
    }

    public function getProductId() {
        return $this->productId;
    }

    public function setProductId($productId) {
        $this->productId = $productId;
    }

    public function getProductName() {
        return $this->productName;
    }

    public function setProductName($productName) {
        $this->productName = $productName;
    }

    public function getProductPrice() {
        return $this->productPrice;
    }

    public function setProductPrice($productPrice) {
        $this->productPrice = $productPrice;
    }

    public function getProductHandleId() {
        return $this->productHandleId;
    }

    public function setProductHandleId($productHandleId) {
        $this->productHandleId = $productHandleId;
    }

    public function getProductImage() {
        return $this->productImage;
    }

    public function setProductImage($productImage) {
        $this->productImage = $productImage;
    }

    public function getProductPercentage() {
        return $this->productPercentage;
    }

    public function setProductPercentage($productPercentage) {
        $this->productPercentage = $productPercentage;
    }

    public function setDOAUrlData($DOAUrldata) {
        $this->DOAUrldata = $DOAUrldata;
    }

    public function getProductUrl() {
        return $this->productUrl;
    }

    public function setProductUrl($productUrl) {
        $this->productUrl = $productUrl;
    }

}
