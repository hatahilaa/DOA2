-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 05, 2018 at 01:29 PM
-- Server version: 5.7.22
-- PHP Version: 7.0.29-1+ubuntu17.10.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `affiliation`
--

-- --------------------------------------------------------

--
-- Table structure for table `Agent`
--

CREATE TABLE `Agent` (
  `agentId` int(10) NOT NULL,
  `agentAccount` varchar(250) NOT NULL,
  `agentEmail` varchar(255) NOT NULL,
  `agentUsername` varchar(250) NOT NULL,
  `agentPassword` varchar(250) NOT NULL,
  `agentHandleId` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Agent`
--

INSERT INTO `Agent` (`agentId`, `agentAccount`, `agentEmail`, `agentUsername`, `agentPassword`, `agentHandleId`) VALUES
(1, 'Account', 'Agent Email', 'Agent Username', 'Agent Password', 'HandleID');

-- --------------------------------------------------------

--
-- Table structure for table `Product`
--

CREATE TABLE `Product` (
  `productId` int(10) NOT NULL,
  `productName` varchar(250) NOT NULL,
  `productHandleId` varchar(250) NOT NULL,
  `productPrice` int(10) NOT NULL,
  `percentage` int(2) NOT NULL,
  `productImage` varchar(250) NOT NULL,
  `productUrl` text NOT NULL,
  `DOAUrldata` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Product`
--

INSERT INTO `Product` (`productId`, `productName`, `productHandleId`, `productPrice`, `percentage`, `productImage`, `productUrl`, `DOAUrldata`) VALUES
(1, 'Pname', 'HandleID', 1000, 5, 'PImage', '', ''),
(2, 'productName', 'HID', 1000, 5, 'productImage', '', ''),
(3, 'productName', 'HID', 1000, 5, 'productImage', '', ''),
(4, 'productName', 'HID', 10000, 15, 'productImage', '', ''),
(5, 'productName', 'HID', 10000, 15, 'productImage', '', ''),
(6, 'productName', 'HID', 0, 15, 'productImage', 'Product URL', '{	\n	\"values\": [{\n		\"type\": \"productId\",\n		\"value\": \"1\",\n		\"adminRead\": true,\n		\"adminWrite\": true,\n		\"publicRead\": true,\n		\"publicWrite\": false,\n		\"index\": \"1001\"\n                \n	          }, \n                  {\n                    \"type\":\"productName\",\n                    \"value\":\"\",\n                    \"adminRead\": true,\n                    \"adminWrite\": true,\n                    \"publicRead\": true,\n		    \"publicWrite\": false,\n		    \"index\": \"1002\"\n                \n	          \n                  }, \n                  {\n                    \"type\":\"productPrice\",\n                    \"value\":\"\",\n                    \"adminRead\": true,\n                    \"adminWrite\": true,\n                    \"publicRead\": true,\n		    \"publicWrite\": false,\n		    \"index\": \"1003\"\n                \n	          \n                  }, \n                  {\n                    \"type\":\"percentage\",\n                    \"value\":\"\",\n                    \"adminRead\": true,\n                    \"adminWrite\": true,\n                    \"publicRead\": true,\n		    \"publicWrite\": false,\n		    \"index\": \"1004\"\n                \n	          \n                  }, \n                  {\n                    \"type\":\"productImage\",\n                    \"value\":\"\",\n                    \"adminRead\": true,\n                    \"adminWrite\": true,\n                    \"publicRead\": true,\n		    \"publicWrite\": false,\n		    \"index\": \"1005\"\n                \n	          \n                  }]\n               }'),
(7, 'productName', 'HID', 0, 15, 'productImage', 'Product URL', '{	\n	\"values\": [{\n		\"type\": \"productId\",\n		\"value\": \"1\",\n		\"adminRead\": true,\n		\"adminWrite\": true,\n		\"publicRead\": true,\n		\"publicWrite\": false,\n		\"index\": \"1001\"\n                \n	          }, \n                  {\n                    \"type\":\"productName\",\n                    \"value\":\"\",\n                    \"adminRead\": true,\n                    \"adminWrite\": true,\n                    \"publicRead\": true,\n		    \"publicWrite\": false,\n		    \"index\": \"1002\"\n                \n	          \n                  }, \n                  {\n                    \"type\":\"productPrice\",\n                    \"value\":\"\",\n                    \"adminRead\": true,\n                    \"adminWrite\": true,\n                    \"publicRead\": true,\n		    \"publicWrite\": false,\n		    \"index\": \"1003\"\n                \n	          \n                  }, \n                  {\n                    \"type\":\"percentage\",\n                    \"value\":\"\",\n                    \"adminRead\": true,\n                    \"adminWrite\": true,\n                    \"publicRead\": true,\n		    \"publicWrite\": false,\n		    \"index\": \"1004\"\n                \n	          \n                  }, \n                  {\n                    \"type\":\"productImage\",\n                    \"value\":\"\",\n                    \"adminRead\": true,\n                    \"adminWrite\": true,\n                    \"publicRead\": true,\n		    \"publicWrite\": false,\n		    \"index\": \"1005\"\n                \n	          \n                  }]\n               }');

-- --------------------------------------------------------

--
-- Table structure for table `sellingProduct`
--

CREATE TABLE `sellingProduct` (
  `selId` int(11) NOT NULL,
  `TransactionHandleId` varchar(250) NOT NULL,
  `selProduct` int(11) NOT NULL,
  `selAgent` int(11) NOT NULL,
  `selDate` date NOT NULL,
  `selResponse` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sellingProduct`
--

INSERT INTO `sellingProduct` (`selId`, `TransactionHandleId`, `selProduct`, `selAgent`, `selDate`, `selResponse`) VALUES
(1, 'HID', 2343, 121, '2018-05-04', 'Response');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Agent`
--
ALTER TABLE `Agent`
  ADD PRIMARY KEY (`agentId`);

--
-- Indexes for table `Product`
--
ALTER TABLE `Product`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `sellingProduct`
--
ALTER TABLE `sellingProduct`
  ADD PRIMARY KEY (`selId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Agent`
--
ALTER TABLE `Agent`
  MODIFY `agentId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Product`
--
ALTER TABLE `Product`
  MODIFY `productId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `sellingProduct`
--
ALTER TABLE `sellingProduct`
  MODIFY `selId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
