<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DBUtil
 *
 * @author hilaire
 */
class DBUtil {

    //put your code here
    private $host;
    private $user;
    private $password;
    private $db;
    private $conn;
    private $hostParams; //DB parameters
    public function setParams() {
        $this->hostParams = array(
            0 => "localhost",
            1 => "root",
            2 => "Hatahila@2017",
            3 => "affiliation"
        );
        return $this->hostParams;
    }
    public function getHostParameters($host = array()){
        $this->host = $host[0];
        $this->user =$host[1];
        $this->password = $host[2];
        $this->db =$host[3];
    }

    public function getConnection() {
        $this->conn = mysqli_connect($this->host, $this->user, $this->password, $this->db);
        return $this->conn;
           
    }
    

}
